import java.util.*;

public class Observador {
    public static void main(String[] args){
        Sujeto s = new Sujeto();
        Observer o = new CObserver();
        Observer o2 = new AnotherObserver();
        s.Attach(o);
        s.Notify("Hola");
        s.Attach(o2);
        s.Notify("Mundo");
        s.Dettach(o);
        s.Notify("Otro Mensaje");
    }
}

class Sujeto{
    public List<Observer> lo;

    Sujeto(){
        this.lo = new ArrayList<Observer>();
    }

    public void Attach(Observer o){
        lo.add(o);
    }

    public void Dettach(Observer o){
        lo.remove(o);
    }

    public void Notify(String evento){
        System.out.println("Enviando mensaje "+evento);
        for (Observer observer : lo) {
            observer.notified(evento);
        }
    }

}


abstract class Observer{
    abstract public void notified(String s);
}

class CObserver extends Observer{
    public void notified(String s){
        System.out.println("Observador 1 Me acabo de enerar de "+s);
    }
}

class AnotherObserver extends Observer{
    public void notified(String s){
        System.out.println("Observador 2 Recibí el mensaje "+s);
    }
}