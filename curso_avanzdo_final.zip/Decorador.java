/*
 * Características fundamentales POO
 * 
 * Encapsulamiento
 * Herencia
 * Polimorfismo
 * Abstracción
 * 
 * SOLID
 * 
 * S Single Responsability Principle
 * O Open Closed Principle 
 * L
 * I
 * D
 * 
 * Clean Code
 * 
 * Helados (calcular el precio)
 * Chocolate
 * Chispas
 * 
 * SQL Query Decorator
 * Componente concreto no decorado
 * SELECT FROM
 * 
 * Decoradores
 * WHERE
 * GROUPBY
 * ORDERBY
 */
public class Decorador {
    public static void main(String[] args){
        Helado h = new Helado(new Bombon(new Bombon(new Chispas(new HeladoFresa()))));
        h.CalculaPrecio();
    }
}

class Helado{
    Helado(Topping t){
        this.t = t;
    }

    Topping t;

    public void CalculaPrecio(){
        float precio = this.t.getPrecio() + 2.0f;
        System.out.println("El precio es"+precio);
    }
}

//Interfaz que puede implemetar métodos
abstract class Topping{
    Topping(Topping t){
        this.t = t;
    }
    Topping(){}
    Topping t;
    abstract public float getPrecio();
}

class HeladoFresa extends Topping{
    public float getPrecio(){
        return 5.0f;
    }
}

class Chocolate extends Topping{
    Chocolate(Topping t){
        this.t = t;
    }
    public float getPrecio(){
        return this.t.getPrecio() + 2.0f;
    }
}

class Chispas extends Topping{
    Chispas(Topping t){
        this.t = t;
    }
    public float getPrecio(){
        return this.t.getPrecio() + 1.2f;
    }
}

class Bombon extends Topping{
    Bombon(Topping t){
        this.t = t;
    }
    public float getPrecio(){
        System.out.println("Agregando bombon");
        return this.t.getPrecio() + 0.8f;
    }
}