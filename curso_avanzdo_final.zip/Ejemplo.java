import java.util.*;

public class Ejemplo{
    public static void main(String[] args){
        

        Conexion c = Conexion.newConnection();
        c.getConnection();

        c.nombre = "Usuario Invalido";

        Conexion d = Conexion.newConnection();
        d.getConnection();

        System.out.println(c == d);
    }
}

class Conexion{
    String nombre;
    String usuario;
    String passwd;
    private static Conexion c = new Conexion("admin", "admin", "passwd");

    static Conexion newConnection(){
        if(Conexion.c.nombre != "admin"){
            Conexion.c.nombre = "admin";
        }
        return Conexion.c;
    }

    private Conexion(String nombre, String usuario, String passwd){
        this.nombre = nombre;
        this.usuario = usuario;
        this.passwd = passwd;
    }

    public void getConnection(){
        System.out.println("Bienvenido "+this.nombre);
    }
}

class Auto{
    String marca;
    String modelo;

    public Auto(String marca, String modelo){
        this.marca = marca;
        this.modelo = modelo;
    }
}