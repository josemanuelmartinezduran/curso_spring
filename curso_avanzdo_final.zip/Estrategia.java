import java.util.*;

public class Estrategia{
    public static void main(String[] args){
        List<IFlyable> lf = new Vector<IFlyable>();
        lf.add(new MallardDuck());
        lf.add(new PatoRojo());
        lf.add(new RubberDuck());

        for (IFlyable iFlyable : lf) {
            iFlyable.Fly();
        }
        Pato p = new Pato(new PatoRojo());
        Pato.DoMallardDuck(Pato.MallardApdapter(p));
    }
}



class Pato {
    static MallardDuck MallardApdapter(Pato p){
        return new MallardDuck();
    }

    static void DoMallardDuck(MallardDuck m){

    }

    Pato(IFlyable f){
        this.f = f;
    }
    IFlyable f;
    public void vuela(){
        f.Fly();
    }
    public void quack(){
        System.out.println("Cuack");
    }
}

interface IFlyable{
    public void Fly();
}

/*
 * Open closed principle 
 * Open to extension
 * Closed to modification
 */
class MallardDuck implements IFlyable{
    public void Fly(){
        System.out.println("Estoy volando");
    }
}

class RubberDuck implements IFlyable{
    public void Fly(){
        System.out.println("Yo no vuelo modificado");
    }
}

class PatoRojo implements IFlyable{
    public void Fly(){
        System.out.println("Pato rojo volando");
    }
}