package curso.spring.alumnos;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import curso.spring.alumnos.controllers.AlumnoController;

@SpringBootTest
class AlumnosApplicationTests {

	@Autowired
	AlumnoController alumnoController;

	@Test
	void contextLoads() throws Exception{
		String resultado = alumnoController.grupoMasAlumnos();
		System.out.println("**************************"+resultado);
	}

}
