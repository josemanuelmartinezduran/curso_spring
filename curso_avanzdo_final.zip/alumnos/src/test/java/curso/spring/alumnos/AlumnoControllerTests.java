package curso.spring.alumnos;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import curso.spring.alumnos.controllers.AlumnoController;
import curso.spring.alumnos.models.GrupoModel;
import curso.spring.alumnos.service.AlumnoService;


@WebMvcTest(AlumnoController.class)
public class AlumnoControllerTests {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AlumnoService alumnoService;

    @Test
    public void testGrupoMasAlumnos() throws Exception {
        // Datos de prueba
        String grupoEsperado = "Grupo A";

        // Configurar el comportamiento del mock
        when(alumnoService.findGrupoWithMostStudents()).thenReturn(grupoEsperado);

        // Realizar la petición GET y verificar la respuesta
        mockMvc.perform(get("/grupomax")) 
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").value(grupoEsperado));
    }
}