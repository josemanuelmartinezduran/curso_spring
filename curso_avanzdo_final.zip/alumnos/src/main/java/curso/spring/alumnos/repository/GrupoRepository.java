package curso.spring.alumnos.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import curso.spring.alumnos.models.GrupoModel;
import java.util.*;

public interface GrupoRepository extends CrudRepository<GrupoModel, Long>{

    //@Query("SELECT g.name FROM GrupoModel g LEFT JOIN AlumnoModel a ON g.id = a.grupo.grupo_id GROUP BY g.nombre ORDER BY DESC")
    //List<String> findGrupoWithMostStudents();

    @Query(value="SELECT g.*, COUNT(g.*) AS alumnos_inscritos FROM grupo AS g LEFT JOIN alumno AS a ON g.id = a.grupo_id GROUP BY g.id ORDER BY alumnos_inscritos DESC", nativeQuery = true)
    List<GrupoModel> obteneEstudiantesGrupo();
    
}
