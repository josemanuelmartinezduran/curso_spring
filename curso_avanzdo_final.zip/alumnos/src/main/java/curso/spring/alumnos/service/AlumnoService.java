package curso.spring.alumnos.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import curso.spring.alumnos.models.AlumnoModel;
import curso.spring.alumnos.models.GrupoModel;
import curso.spring.alumnos.pdo.AlumnoParamPDO;
import curso.spring.alumnos.repository.AlumnoRepository;
import curso.spring.alumnos.repository.GrupoRepository;

import java.util.*;

@Service
public class AlumnoService{
    @Autowired
    AlumnoRepository alumnoRepository;

    @Autowired
    GrupoRepository grupoRepository;

    public ArrayList<AlumnoModel> obtenerAlumnos(){
        return (ArrayList<AlumnoModel>)alumnoRepository.findAll();
    }

    public AlumnoModel guardarAlumno(AlumnoModel alumno){
        return alumnoRepository.save(alumno);
    }

    public Boolean deleteById(Long id){
        try{
            alumnoRepository.deleteById(id);
            return true;
        } catch(IllegalArgumentException e) {
            System.out.println(e);
            return false;
        }   
    }

    public Optional<AlumnoModel> getById(Long idLong){
        return alumnoRepository.findById(idLong);
    }

    public boolean updateAlumno(AlumnoModel alumno){
        if(alumno.getId() > 0){
            alumnoRepository.save(alumno);
            return true;
        } else{
            return false;
        }
        
    }

    public Set<AlumnoModel>buscarAlumnosPorNombreYGrupo(String nombre, Long grupoId){
        return alumnoRepository.buscarAlumnosPorNombreYGrupo(nombre, grupoId);
    }

    public AlumnoModel finAlumnoByIdQyery(Long id){
        return alumnoRepository.findAlumnoById(id);
    }

    public List<AlumnoModel> buscaAlumnoPDO(AlumnoParamPDO alumnopdo){
        return alumnoRepository.buscaAlumnoPDO(alumnopdo);
    }

    public String findGrupoWithMostStudents(){
        List<GrupoModel> sl = grupoRepository.obteneEstudiantesGrupo();
        for (GrupoModel grupoModel : sl) {
            return grupoModel.getNombre();
        }
        return null;
    }

}
