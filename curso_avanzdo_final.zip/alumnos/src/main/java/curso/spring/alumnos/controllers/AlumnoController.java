package curso.spring.alumnos.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import curso.spring.alumnos.service.AlumnoService;
import curso.spring.alumnos.models.AlumnoModel;
import curso.spring.alumnos.models.GrupoModel;
import curso.spring.alumnos.pdo.AlumnoParamPDO;

import java.util.*;


@RestController
public class AlumnoController {
    @Autowired
    AlumnoService alumnoService;

    @GetMapping("/")
    public String getMethodName() {
        return "";
    }

    @PostMapping("/alumno")
    public AlumnoModel guardaUsuario(@RequestBody AlumnoModel alumno){
        return this.alumnoService.guardarAlumno(alumno);
    }

    @GetMapping("/alumnos")
    public ArrayList<AlumnoModel> getUsuarios(){
        return this.alumnoService.obtenerAlumnos();
    }

    @DeleteMapping("/alumno")
    public Boolean deleteUser(@RequestBody AlumnoModel alumno){
        return this.alumnoService.deleteById(alumno.getId());
    }

    @PostMapping("/buscaAlumnoPDO")
    public List<AlumnoModel> buscaByNameGrupPDO(@RequestBody AlumnoParamPDO alumnopdo){
        return this.alumnoService.buscaAlumnoPDO(alumnopdo);
    }

    @GetMapping(path = ("/alumno/{id}"))
    public Optional<AlumnoModel> getById(@PathVariable("id") Long id){
        return this.alumnoService.getById(id);
    }

    @GetMapping(path = ("/alumnoquery/{id}"))
    public AlumnoModel getByIdQuery(@PathVariable("id") Long id){
        return this.alumnoService.finAlumnoByIdQyery(id);
    }

    @PutMapping(path = ("/alumno/{id}"))
    public boolean updateAlumno(@RequestBody AlumnoModel alumno){
        return this.alumnoService.updateAlumno(alumno);
    }

    @GetMapping("/grupomax")
    public String grupoMasAlumnos() throws Exception{
        String retorno = this.alumnoService.findGrupoWithMostStudents();
        if(retorno == null)
            throw new Exception("Error al ejecutar ************************");
        return retorno;
    }

    @GetMapping("/populate")
    public String populateDB() {
        AlumnoModel a = new AlumnoModel();
        a.setNombre("Jose");
        this.alumnoService.guardarAlumno(a);
        a = new AlumnoModel();
        a.setNombre("Juan");
        this.alumnoService.guardarAlumno(a);
        a = new AlumnoModel();
        a.setNombre("Raul");
        this.alumnoService.guardarAlumno(a);
        return "Alumnos creados";
    }


    
}

