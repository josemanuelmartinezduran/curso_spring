package curso.spring.alumnos.pdo;

import lombok.Getter;
import lombok.Setter;
//DAO Data Access Object
public class AlumnoParamPDO {
    @Setter
    @Getter
    String nombre;

    @Setter
    @Getter
    Long groupID;
}
