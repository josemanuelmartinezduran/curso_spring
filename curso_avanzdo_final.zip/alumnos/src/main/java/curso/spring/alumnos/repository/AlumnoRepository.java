package curso.spring.alumnos.repository;

import java.util.*;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import curso.spring.alumnos.models.AlumnoModel;
import curso.spring.alumnos.pdo.AlumnoParamPDO;

public interface AlumnoRepository extends CrudRepository<AlumnoModel, Long> {
    // public abstract List<AlumnoModel> findByNombre(String nombre);
    @Query("SELECT a FROM AlumnoModel a WHERE a.Id = :id")
    AlumnoModel findAlumnoById(@Param("id") long id);

    @Query("SELECT a FROM AlumnoModel a WHERE a.nombre LIKE %:nombre%")
    List<AlumnoModel> findAlumnosByNombre(@Param("nombre") String nombre);

    @Query("SELECT a FROM AlumnoModel a WHERE a.grupo.id = :grupoId")
    List<AlumnoModel> findAlumnosByGrupoId(@Param("grupoId") long grupoId);

    @Query("SELECT a FROM AlumnoModel a WHERE a.grupo IS NULL")
    List<AlumnoModel> findAlumnosSinGrupo();

    @Query("SELECT a FROM AlumnoModel a WHERE a.id= :#{#alumnoPDO.id} AND a.grupo.id= :#{#alumnoPDO.groupID}")
    public List<AlumnoModel> buscaAlumnoPDO(@Param("alumnoPDO") AlumnoParamPDO alumnopdo);

    // Query nativa
    @Query(value = "SELECT * FROM alumno", nativeQuery = true)
    List<AlumnoModel> findAllAlumnosNQ();

    @Query(value = "SELECT * FROM alumno WHERE id = :id", nativeQuery = true)
    AlumnoModel findAlumnoByIdNQ(@Param("id") long id);

    @Query(value = "SELECT * FROM alumno WHERE nombre LIKE :nombre", nativeQuery = true)
    List<AlumnoModel> findAlumnosByNombreNQ(@Param("nombre") String nombre);

    @Query(value = "SELECT * FROM alumno WHERE grupo_id = :grupoId", nativeQuery = true)
    List<AlumnoModel> findAlumnosByGrupoIdNQ(@Param("grupoId") long grupoId);

    @Query(value = "SELECT * FROM alumno WHERE grupo_id IS NULL", nativeQuery = true)
    List<AlumnoModel> findAlumnosSinGrupoNQ();

    @Query(value = "SELECT * FROM alumno WHERE grupo_id = :grupoId AND nombre = :nombre", nativeQuery = true)
    public Set<AlumnoModel> buscarAlumnosPorNombreYGrupo(String nombre, Long grupoId);

    @Query(value = "SELECT g.name, COUNT(g.id) FROM alumno WHERE grupo_id = :grupoId AND nombre = :nombre", nativeQuery = true)
    public Set<AlumnoModel> getGrupoMaxAlumnos(String nombre, Long grupoId);
    
    @Procedure(value = "CAR.GET_TOTAL_CARS")
    int GET_TOTAL_CARS_BY_MODEL(String model);
}