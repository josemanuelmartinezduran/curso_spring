package curso.spring.alumnos.models;

import com.fasterxml.jackson.annotation.*;

import jakarta.persistence.*;
import lombok.*;


@Entity
@Data
@Table(name = "alumno")
public class AlumnoModel {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private long id;

    String nombre;

    @ManyToOne()
    @JsonManagedReference
    @JoinColumn(name="grupo_id", nullable=true)
    private GrupoModel grupo;
}

/* @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "address_id", referencedColumnName = "id")
    private Address address; */

/* /    
@OneToMany(mappedBy="cart")
    private Set<Item> items;

@ManyToOne
    @JoinColumn(name="cart_id", nullable=false)
    private Cart cart;

    @Query("SELECT a FROM AlumnoModel a")
List<AlumnoModel> findAllAlumnos();

@Query("SELECT a FROM AlumnoModel a WHERE a.id = :id")
AlumnoModel findAlumnoById(@Param("id") long id);

@Query("SELECT a FROM AlumnoModel a WHERE a.nombre LIKE %:nombre%")
List<AlumnoModel> findAlumnosByNombre(@Param("nombre") String nombre);

@Query("SELECT a FROM AlumnoModel a WHERE a.grupo.id = :grupoId")
List<AlumnoModel> findAlumnosByGrupoId(@Param("grupoId") long grupoId);

@Query("SELECT a FROM AlumnoModel a WHERE a.grupo IS NULL")
List<AlumnoModel> findAlumnosSinGrupo();
     */