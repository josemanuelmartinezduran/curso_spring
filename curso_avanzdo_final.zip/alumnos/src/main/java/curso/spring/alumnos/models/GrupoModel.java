package curso.spring.alumnos.models;


import jakarta.persistence.*;
import lombok.*;
import java.util.*;

import com.fasterxml.jackson.annotation.*;

@Entity
@Data
@Table(name = "grupo")
public class GrupoModel {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private long id;

    String nombre;

    @Transient
    Integer alumnos_inscritos;

    @OneToMany(mappedBy="grupo", cascade=CascadeType.PERSIST)
    @JsonBackReference
    private Set<AlumnoModel> items;
}
