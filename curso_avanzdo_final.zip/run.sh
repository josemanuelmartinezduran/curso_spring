#!/bin/bash
javac Estrategia.java
java Estrategia