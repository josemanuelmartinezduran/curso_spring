package hello.world.sample.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController{
    @GetMapping("/")
    public String getMethodName() {
        return "Hello World desde Kubenetes";
    }
}

